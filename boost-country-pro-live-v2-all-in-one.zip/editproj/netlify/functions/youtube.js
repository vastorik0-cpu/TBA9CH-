const YT='https://www.googleapis.com/youtube/v3';
exports.handler=async(event)=>{
  if(event.httpMethod!=='POST') return res(405,{error:'POST only'});
  try{
    const b=JSON.parse(event.body||'{}');
    const key=b.apiKey||process.env.YOUTUBE_API_KEY;
    if(!key) return res(400,{error:'Add YOUTUBE_API_KEY in Netlify environment variables, or enter an API key in Settings.'});
    if(b.action==='init') return res(200,await init(b.videoId,key));
    if(b.action==='chat') return res(200,await chat(b.liveChatId,b.pageToken,key));
    if(b.action==='stats') return res(200,await stats(b.videoId,b.channelId,key));
    return res(400,{error:'Unknown action'});
  }catch(e){return res(500,{error:e.message})}
};
function res(status,body){return{statusCode:status,headers:{'content-type':'application/json','access-control-allow-origin':'*'},body:JSON.stringify(body)}}
async function get(path,params){const u=new URL(YT+path);Object.entries(params).forEach(([k,v])=>{if(v!==undefined&&v!==null&&v!=='')u.searchParams.set(k,v)});const r=await fetch(u);const j=await r.json();if(!r.ok)throw new Error(j.error?.message||'YouTube API request failed');return j}
async function init(videoId,key){if(!videoId)throw new Error('Missing video ID');const j=await get('/videos',{part:'snippet,liveStreamingDetails,statistics',id:videoId,key});if(!j.items?.length)throw new Error('Video not found');const v=j.items[0];const liveChatId=v.liveStreamingDetails?.activeLiveChatId;if(!liveChatId)throw new Error('This video is not currently exposing an active live chat. Start the live stream first.');return{title:v.snippet.title,channelId:v.snippet.channelId,liveChatId,likes:Number(v.statistics?.likeCount||0),subscribers:0,viewers:Number(v.liveStreamingDetails?.concurrentViewers||0)}}
async function chat(liveChatId,pageToken,key){if(!liveChatId)throw new Error('Missing liveChatId');return await get('/liveChat/messages',{part:'snippet,authorDetails',liveChatId,pageToken,maxResults:200,key})}
async function stats(videoId,channelId,key){const v=await get('/videos',{part:'statistics,liveStreamingDetails',id:videoId,key});const likes=Number(v.items?.[0]?.statistics?.likeCount||0);let subscribers=0;if(channelId){const c=await get('/channels',{part:'statistics',id:channelId,key});subscribers=Number(c.items?.[0]?.statistics?.subscriberCount||0)}return{likes,subscribers,viewers:Number(v.items?.[0]?.liveStreamingDetails?.concurrentViewers||0)}}
